import React from "react";

function Componente1() {
  return <div>Componente 1</div>;
}

export default Componente1;
