import React from "react";

function Componente3() {
  return <div>Componente 3</div>;
}

export default Componente3;
